% using velocity data
clc;
clear all;
X = [300;100;200;60]; % initial state given
P = eye(4)*1e4; % initial uncertainity

A=[0,1,0,0;
   0,0,0,0;
   0,0,0,1;
   0,0,0,0];

B=[0;
   0;
   0;
  -1];

C = [0,1,0,0;
     0,0,0,1];

D=[0;
   0];

T = 1/100;

sys_continous = ss(A,B,C,D); % creating and simulating state space model
sys_discrete =c2d(sys_continous,T);

Ad = sys_discrete.A;
Bd = sys_discrete.B;
Cd = sys_discrete.C;
Dd = sys_discrete.D;

R = [4,0;0,16]; % measurement covariance
disp_data = readmatrix('HW1_Q1_Displacement_Measurements.txt'); % Reading given data
vel_data = readmatrix('HW1_Q1_Velocity_Measurements.txt');

F = Ad; % Renaming for ease
G = Bd; 
H = Cd; 

u = 9.81;
extrapolated_value=[];
for i = 1:size(vel_data, 1)
    X_pred = F*X + G*u; %State prediction
    P_pred = F*P*transpose(F); %Covariance prediction
    K = (P_pred*transpose(H))*inv(H*P_pred*transpose(H) + R); % Kalman gain computation
    X = X_pred + K*([vel_data(i,2);vel_data(i,3)] - H*X_pred); %State update equation
    P = (eye(4) - K*H)*P_pred*transpose((eye(4)-K*H)) + K*R*transpose(K); %Covariance update equation
    extrapolated_value = [extrapolated_value;[vel_data(i,1),X(1,1),X(2,1),X(3,1),X(4,1)]];
end

figure(1);
plot(vel_data(:,1),extrapolated_value(:,2), "b-")
grid on
xlabel('Time (t) [sec]')
ylabel('Displacement X-direction (x) [m]')
title('Displacement X-direction v/s Time')
hold on
plot(vel_data(:,1),disp_data(:,2), "r-")
legend('Kalman Filtered Data', 'Noisy Measurement Data')
hold off

figure(2);
plot(vel_data(:,1),extrapolated_value(:,4), "b-")
grid on
xlabel('Time (t) [sec]')
ylabel('Displacement Y-direction (x) [m]')
title('Displacement Y-direction v/s Time')
hold on
plot(vel_data(:,1),disp_data(:,3), "r-")
legend('Kalman Filtered Data', 'Noisy Measurement Data')
hold off

figure(3);
plot(vel_data(:,1),extrapolated_value(:,3), "b-")
grid on
xlabel('Time (t) [sec]')
ylabel('Velocity X-direction (x) [m]')
title('Velocity X-direction v/s Time')
hold on
plot(vel_data(:,1),vel_data(:,2), "r-")
legend('Kalman Filtered Data', 'Noisy Measurement Data')
hold off

figure(4);
plot(vel_data(:,1),extrapolated_value(:,5), "b-")
grid on
xlabel('Time (t) [sec]')
ylabel('Velocity Y-direction (x) [m]')
title('Velocity Y-direction v/s Time')
hold on
plot(vel_data(:,1),vel_data(:,3), "r-")
legend('Kalman Filtered Data', 'Noisy Measurement Data')
hold off

%% 2nd error covariance matrix
X = [300;100;200;60]; % initial state given
P = eye(4)*1e8; % initial uncertainity

A=[0,1,0,0;
   0,0,0,0;
   0,0,0,1;
   0,0,0,0];

B=[0;
   0;
   0;
  -1];

C = [0,1,0,0;
     0,0,0,1];

D=[0;
   0];

T = 1/100;
sys_continous = ss(A,B,C,D); % creating and simulating state space model
sys_discrete =c2d(sys_continous,T);

Ad = sys_discrete.A;
Bd = sys_discrete.B;
Cd = sys_discrete.C;
Dd = sys_discrete.D;


R = [4,0;0,16]; % measurement covariance
disp_data = readmatrix('HW1_Q1_Displacement_Measurements.txt'); % Reading given data
vel_data = readmatrix('HW1_Q1_Velocity_Measurements.txt');

F = Ad; % Renaming for ease
G = Bd; 
H = Cd; 

u = 9.81;
extrapolated_value=[];
for i = 1:size(vel_data, 1)
    X_pred = F*X + G*u; %State prediction
    P_pred = F*P*transpose(F); %Covariance prediction
    K = (P_pred*transpose(H))*inv(H*P_pred*transpose(H) + R); % Kalman gain computation
    X = X_pred + K*([vel_data(i,2);vel_data(i,3)] - H*X_pred); %State update equation
    P = (eye(4) - K*H)*P_pred*transpose((eye(4)-K*H)) + K*R*transpose(K); %Covariance update equation
    extrapolated_value = [extrapolated_value;[vel_data(i,1),X(1,1),X(2,1),X(3,1),X(4,1)]];
end

figure(5);
plot(vel_data(:,1),extrapolated_value(:,2), "b-")
grid on
xlabel('Time (t) [sec]')
ylabel('Displacement X-direction (x) [m]')
title('Displacement X-direction v/s Time')
hold on
plot(vel_data(:,1),disp_data(:,2), "r-")
legend('Kalman Filtered Data', 'Noisy Measurement Data')
hold off

figure(6);
plot(vel_data(:,1),extrapolated_value(:,4), "b-")
grid on
xlabel('Time (t) [sec]')
ylabel('Displacement Y-direction (x) [m]')
title('Displacement Y-direction v/s Time')
hold on
plot(vel_data(:,1),disp_data(:,3), "r-")
legend('Kalman Filtered Data', 'Noisy Measurement Data')
hold off

figure(7);
plot(vel_data(:,1),extrapolated_value(:,3), "b-")
grid on
xlabel('Time (t) [sec]')
ylabel('Velocity X-direction (x) [m]')
title('Velocity X-direction v/s Time')
hold on
plot(vel_data(:,1),vel_data(:,2), "r-")
legend('Kalman Filtered Data', 'Noisy Measurement Data')
hold off

figure(8);
plot(vel_data(:,1),extrapolated_value(:,5), "b-")
grid on
xlabel('Time (t) [sec]')
ylabel('Velocity Y-direction (x) [m]')
title('Velocity Y-direction v/s Time')
hold on
plot(vel_data(:,1),vel_data(:,3), "r-")
legend('Kalman Filtered Data', 'Noisy Measurement Data')
hold off











