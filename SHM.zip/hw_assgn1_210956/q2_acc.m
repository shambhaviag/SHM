clc;
clear all;
% for acceleration
measurement_data=readmatrix('HW1_Q2_Measurements.txt');
motion_data=readmatrix('HW1_Q2_El_Centro.txt');

% system dynamics
A = [0,0,1,0;
    0,0,0,1;
    -2000,1000,-6.352,3.176;
    1000,-1000,3.176,-3.176];
B = [0;0;-1;-1];

C = [-2000,1000,-6.352,3.176;
    1000,-1000,3.176,-3.176];

D = [0; 0];

T = 1/200; % Sampling time

X=[0;0;0;0]; % initial vector
P=eye(4)*1e3; % assumed initial uncertainity
R=[0.105,0;
    0,0.162];  % measurement noise covariance

sys_continuous = ss(A,B,C,D);  % discretize system dynamics
sys_discrete =c2d(sys_continuous,T);

Ad = sys_discrete.A;
Bd = sys_discrete.B;
Cd = sys_discrete.C;
Dd = sys_discrete.D;

extrapolated_value= [];

F = Ad; % State transition matrix
G = Bd; % Control input matrix
H = Cd; % Measurement matrix

meas_data_200hz=[];

for i=1:size(motion_data,1)-1
    meas_data_200hz=[meas_data_200hz;motion_data(i,:)];
    meas_data_200hz=[meas_data_200hz;motion_data(i,:)];
    meas_data_200hz=[meas_data_200hz;motion_data(i,:)];
    meas_data_200hz=[meas_data_200hz;motion_data(i,:)];
end

meas_data_200hz=[meas_data_200hz;motion_data(i,:)];

for i=1:size(meas_data_200hz,1)
    u=meas_data_200hz(i,2);
    X_pred = F*X + G*u; %State extrapolation
    P_pred = F*P*transpose(F); %Covariance extrapolation
    K = (P_pred*transpose(H))*inv(H*P_pred*transpose(H) + R);
    X = X_pred + K*([measurement_data(i,4);measurement_data(i,5)] - H*X_pred); %State update eqn
    L= H*X;
    P = (eye(4) - K*H)*P_pred*transpose((eye(4)-K*H)) + K*R*transpose(K); %Covariance update eqn
    extrapolated_value = [extrapolated_value;[meas_data_200hz(i,1),X(1,1),X(2,1),L(1,1),L(2,1)]];
end

t = 0:0.005:53.74;

figure(1);
plot(t,extrapolated_value(:,2), "b-")
grid on
xlabel('Time (t) [sec]')
ylabel('Displacement of Story 1 [m]')
title('Displacement of Story 1 v/s Time')
hold on
plot(t,measurement_data(:,2), "r-")
legend('Kalman Filtered Data', 'Noisy Measurement Data')
hold off

figure(2);
plot(t,extrapolated_value(:,3), "b-")
grid on
xlabel('Time (t) [sec]')
ylabel('Displacement of Story 2 [m]')
title('Displacement of Story 2 v/s Time')
hold on
plot(t,measurement_data(:,3), "r-")
legend('Kalman Filtered Data', 'Noisy Measurement Data')
hold off

figure(3);
plot(t,extrapolated_value(:,4), "b-")
grid on
xlabel('Time (t) [sec]')
ylabel('Acceleration of Story 1 [m]')
title('Acceleration of Story 1 v/s Time')
hold on
plot(t,measurement_data(:,4), "r-")
legend('Kalman Filtered Data', 'Noisy Measurement Data')
hold off

figure(4);
plot(t,extrapolated_value(:,5), "b-")
grid on
xlabel('Time (t) [sec]')
ylabel('Acceleration of Story 2 [m]')
title('Acceleration of Story 2 v/s Time')
hold on
plot(t,measurement_data(:,5), "r-")
legend('Kalman Filtered Data', 'Noisy Measurement Data')
hold off


measurement_data=readmatrix('HW1_Q2_Measurements.txt');
motion_data=readmatrix('HW1_Q2_El_Centro.txt');
X=[0;0;0;0]; % initial vector
P=eye(4)*1e3; % assumed initial uncertainity
Q=eye(4)*1e4; % assumed process noise covariance
R=[0.105,0;
    0,0.162];  % measurement noise covariance
A = [0,0,1,0;
    0,0,0,1;
    -2000,1000,-6.352,3.176;
    1000,-1000,3.176,-3.176];
B = [0;0;-1;-1];

C = [-2000,1000,-6.352,3.176;
    1000,-1000,3.176,-3.176];

D = [0; 0];

T = 1/200;

sys_continuous = ss(A,B,C,D);
sys_discrete =c2d(sys_continuous,T);

Ad = sys_discrete.A;
Bd = sys_discrete.B;
Cd = sys_discrete.C;
Dd = sys_discrete.D;

extrapolated_value= [];

H = Cd; % Measurement matrix
F = Ad; % State transition matrix
G = Bd; % Control input matrix
meas_data_200hz=[];

for i=1:size(motion_data,1)-1
    meas_data_200hz=[meas_data_200hz;motion_data(i,:)];
    meas_data_200hz=[meas_data_200hz;motion_data(i,:)];
    meas_data_200hz=[meas_data_200hz;motion_data(i,:)];
    meas_data_200hz=[meas_data_200hz;motion_data(i,:)];
end
meas_data_200hz=[meas_data_200hz;motion_data(i,:)];

for i=1:size(meas_data_200hz,1)
    u=meas_data_200hz(i,2);
    X_pred = F*X + G*u; %State extrapolation
    P_pred = F*P*transpose(F) + Q; %Covariance extrapolation
    K = (P_pred*transpose(H))*inv(H*P_pred*transpose(H) + R);
    X = X_pred + K*([measurement_data(i,4);measurement_data(i,5)] - H*X_pred); %State update eqn
    L= H*X;
    P = (eye(4) - K*H)*P_pred*transpose((eye(4)-K*H)) + K*R*transpose(K); %Covariance update eqn
    extrapolated_value = [extrapolated_value;[meas_data_200hz(i,1),X(1,1),X(2,1),L(1,1),L(2,1)]];
end

figure(5);
plot(t,extrapolated_value(:,2), "b-")
grid on
xlabel('Time (t) [sec]')
ylabel('Displacement of Story 1 [m]')
title('Displacement of Story 1 v/s Time')
hold on
plot(t,measurement_data(:,2), "r-")
legend('Kalman Filtered Data', 'Noisy Measurement Data')
hold off

figure(6);
plot(t,extrapolated_value(:,3), "b-")
grid on
xlabel('Time (t) [sec]')
ylabel('Displacement of Story 2 [m]')
title('Displacement of Story 2 v/s Time')
hold on
plot(t,measurement_data(:,3), "r-")
legend('Kalman Filtered Data', 'Noisy Measurement Data')
hold off

figure(7);
plot(t,extrapolated_value(:,4), "b-")
grid on
xlabel('Time (t) [sec]')
ylabel('Acceleration of Story 1 [m]')
title('Acceleration of Story 1 v/s Time')
hold on
plot(t,measurement_data(:,4), "r-")
legend('Kalman Filtered Data', 'Noisy Measurement Data')
hold off

figure(8);
plot(t,extrapolated_value(:,5), "b-")
grid on
xlabel('Time (t) [sec]')
ylabel('Acceleration of Story 2 [m]')
title('Acceleration of Story 2 v/s Time')
hold on
plot(t,measurement_data(:,5), "r-")
legend('Kalman Filtered Data', 'Noisy Measurement Data')
hold off