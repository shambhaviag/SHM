% Clear workspace and load data
clear; close all;clc;
load('ES_Q1_Data.mat');
load('ES_Q1_NoisyData.mat');
load('Q1_TrueMarkovPara.mat');
load('Q1_TrueModalPara.mat');

% Define time step
time_step = 1/10;

% Choose data source: 'Noisy' or 'Complete'
f_in = f; 
Y_out = Y;

% Number of Markov parameters
num_parameters = 100;

% Create time vector
time_vector = (0:num_parameters-1) * time_step;

% Construct input matrix U_in
n_t = size(f_in);
U_in = zeros(num_parameters, n_t(1));
for i = (num_parameters-1):-1:1
    temp = f_in(i:-1:1, 1);
    U_in(1:i, i) = temp;
end
for i = num_parameters:n_t(1)
    U_in(:, i) = f_in(i:-1:i-(num_parameters-1), 1);
end

% Calculate Markov parameters M
M = Y_out' / U_in;

% Plot Markov parameters
for i = 1:5
    figure;
    plot(time_vector, mark_para(i,:), '-x');
    hold on;
    grid on;
    plot(time_vector, M(i,:), '-');
    hold off;
    xlabel('Time (s)');
    ylabel(['Markov Parameter #', num2str(i)]);
    legend('True', 'Derived', 'Location', 'best');
    title(['Markov Parameter #', num2str(i), ' vs Time']);
end

Hp=40;
H1=zeros(Hp*5,Hp);
for j = 2:Hp+1
    m=1;
    for i = j:j+Hp-1
        temp1(m:m+4,1) = M(:,i);
        m=m+5;
    end
    H1(:,j-1) = temp1(:,1);
end
H2=zeros(Hp*5,Hp);
for j = 3:Hp+2
    m=1;
    for i = j:j+Hp-1
        temp1(m:m+4,1) = M(:,i);
        m=m+5;
    end
    H2(:,j-2) = temp1(:,1);
end
%H1 
%H2
[U,Sigma,V]=svd(H1);
S=sqrt(Sigma);
singular_values=zeros(1,Hp);
for i =1:Hp
    singular_values(i) = Sigma(i,i);
end
figure;
semilogy(singular_values,'*')
grid on
xlabel('Number')
ylabel('Singular Value Magnitude')
%% 
% We can see from the graph that System Order = 6

so = 6;
Ns=5;
Nu=1;

U_truncated = U(:,1:so);
V_truncated = V(:,1:so);
S_truncated = S(1:so,1:so);

P = U_truncated*S_truncated;
Q = S_truncated*V_truncated';

Ad = inv(S_truncated)*U_truncated'*H2*V_truncated*inv(S_truncated)
Cd = P(1:Ns,:)
Bd = Q(:,1:Nu)
Dd = M(:,1)
%%
[eigen_vec,eigen_val]=eig(Ad)
dicrete_time_poles=diag(eigen_val)'
w=zeros(1,so/2);
zita=zeros(1,so/2);
for i=1:2:so
    w(0.5*(i+1))=abs((1/time_step)*log(eigen_val(i,i)));
    zita(0.5*(i+1))=-real((1/time_step)*log(eigen_val(i,i)))/w(0.5*(i+1));
end
Psi=zeros(Ns,so/2);
real_mode_shapes=zeros(Ns,so/2);
for i=1:so/2
    Psi(:,i)=Cd*eigen_vec(:,2*i-1);
    tan_theta_i=-(real(Psi(:,i))'*imag(Psi(:,i)))/(real(Psi(:,i))'*real(Psi(:,i)));
    alpha_i = complex(cos(atan(tan_theta_i)),sin(atan(tan_theta_i)));
    real_mode_shapes(:,i)=alpha_i*Psi(:,i);
end
Complex_Mode_Shape_Vectors = Psi
w
modal_frequencies_calculated=w/(2*pi)
zita
real_mode_shapes
%% 
% By Comparing Modal Parameters with true values we get the identified modes 
% as 5, 3 and 1.

error_freq=zeros(1,so/2);
error_zita=zeros(1,so/2);
MAC=zeros(1,so/2);
for i=1:so/2
    error_freq(i)=(modal_frequencies_calculated(i)-freq(so+1-2*i))/freq(so+1-2*i)*100;
    error_zita(i)=(zita(i)-damp(so+1-2*i))/damp(so+1-2*i)*100;
    MAC(i)=abs(real_mode_shapes(:,i)'*MS(:,so+1-2*i))*abs(real_mode_shapes(:,i)'*MS(:,so+1-2*i))/(abs(real_mode_shapes(:,i)'*real_mode_shapes(:,i))*abs(MS(:,so+1-2*i)'*MS(:,so+1-2*i)));
end
error_zita
%% 
% Percentage error for Mode 5, 3 and 1 respectively

error_freq
%% 
% Percentage error for Mode 5, 3 and 1 respectively

MAC
%% 
% MAC for Mode 5, 3 and 1 respectively
figure;
plot([5 3 1],zita,'*')
hold on
plot(damp,'d')
grid on
xlim([0.5 5.5])
ylim([0.04 0.11])
xlabel('Mode Number')
ylabel('Damping')
legend('derived','true','Location','best')
hold off
figure;
plot([5 3 1],modal_frequencies_calculated,'.')
hold on
plot(freq,'o')
grid on
xlim([0.5 5.5])
xlabel('Mode Number')
ylabel('Frequency')
legend('derived','true','Location','best')
hold off
%%
for i = 1:3
    figure; plot(real(Psi(:,i)),imag(Psi(:,i)),'*');
    grid on; grid minor;
end

%%

function [P, Q, Ad, Cd, Bd, Dd] = calculateSystemMatrices(H2, U_truncated, V_truncated, S_truncated, M)
    P = U_truncated * S_truncated;
    Q = S_truncated * V_truncated';
    Ad = inv(S_truncated) * U_truncated' * H2 * V_truncated * inv(S_truncated);
    Cd = P(1:5, :);
    Bd = Q(:, 1);
    Dd = M(:, 1);
end

function [eigen_vec, eigen_val, w, zita, Psi, real_mode_shapes] = analyzeSystem(Ad, Cd, so, time_step)
    [eigen_vec, eigen_val] = eig(Ad);
    eigen_val = diag(eigen_val)';
    w = zeros(1, so/2);
    zita = zeros(1, so/2);
    for i = 1:2:so
        w(0.5*(i+1)) = abs((1/time_step) * log(eigen_val(i)));
        zita(0.5*(i+1)) = -real((1/time_step) * log(eigen_val(i))) / w(0.5*(i+1));
    end
    Psi = zeros(5, so/2);
    real_mode_shapes = zeros(5, so/2);
    for i = 1:so/2
        Psi(:, i) = Cd * eigen_vec(:, 2*i-1);
        tan_theta_i = -(real(Psi(:, i))' * imag(Psi(:, i))) / (real(Psi(:, i))' * real(Psi(:, i)));
        alpha_i = complex(cos(atan(tan_theta_i)), sin(atan(tan_theta_i)));
        real_mode_shapes(:, i) = alpha_i * Psi(:, i);
    end
end

function [error_freq, error_zita, MAC] = compareModes(w, zita, freq, damp, real_mode_shapes, so, MS)
    error_freq = zeros(1, so/2);
    error_zita = zeros(1, so/2);
    MAC = zeros(1, so/2);
    for i = 1:so/2
        error_freq(i) = (w(i) - freq(so+1-2*i)) / freq(so+1-2*i) * 100;
        error_zita(i) = (zita(i) - damp(so+1-2*i)) / damp(so+1-2*i) * 100;
        MAC(i) = abs(real_mode_shapes(:, i)' * MS(:, so+1-2*i)) * abs(real_mode_shapes(:, i)' * MS(:, so+1-2*i)) / ...
            (abs(real_mode_shapes(:, i)' * real_mode_shapes(:, i)) * abs(MS(:, so+1-2*i)' * MS(:, so+1-2*i)));
    end
end

function visualizeModes(zita, damp, modal_frequencies_calculated, freq)
    figure;
    plot([5 3 1], zita, '*');
    hold on;
    plot(damp, 'd');
    grid on;
    xlim([0.5 5.5]);
    ylim([0.04 0.11]);
    xlabel('Mode Number');
    ylabel('Damping');
    legend('Derived', 'True', 'Location', 'best');
    hold off;
    figure;
    plot([5 3 1], modal_frequencies_calculated, '.');
    hold on;
    plot(freq, 'o');
    grid on;
    xlim([0.5 5.5]);
    xlabel('Mode Number');
    ylabel('Frequency');
    legend('Derived', 'True', 'Location', 'best');
    hold off;
end
