% Clear the command window, workspace, and close all figures
clc; clear; close all;

% Load data from ES_Q2.mat
load ES_Q2.mat

% Define parameters
Nf = 2;         % number of floors
days = 3;       % number of days
time_step = 1/100;  % time step

% Initialize arrays to store natural frequencies and damping ratios
w = zeros(days, Nf);
zita = zeros(days, Nf);

% Loop through each day
j=1;
while j<4
    % Choose appropriate matrices based on the day
    A = eval(['A_day' num2str(j)]);  % Using dynamic variable names
    C = eval(['C_day' num2str(j)]);  % Using dynamic variable names  
    % Compute eigenvalues and eigenvectors of matrix A
    [eigen_vec, eigen_val] = eig(A);
    
    % Calculate natural frequencies and damping ratios
    for i = 1:2:2*Nf
        w(j, 0.5*(i+1)) = abs((1/time_step) * log(eigen_val(i, i)));
        zita(j, 0.5*(i+1)) = -real((1/time_step) * log(eigen_val(i, i))) / w(j, 0.5*(i+1));
    end
    j=j+1;
end




% Display computed natural frequencies and damping ratios
w;
zita;

% Plot natural frequency of Floor 1 over days
figure;
plot([1 2 3], w(:, 1)', '-.x')
xlim([0.5 4])
xlabel('Day Number')
ylabel('Natural Frequency (in rad/s) of Floor 1')
title('Natural Frequency of Floor 1 v/s Day Number')

% Add text annotations for each point
for i = 1:3
    text(i, w(i, 1), ['(', num2str(i), ',', num2str(w(i, 1)), ')'], 'VerticalAlignment', 'bottom', 'HorizontalAlignment', 'left');
end

% Plot natural frequency of Floor 2 over days
figure;
plot([1 2 3], w(:, 2)', '-.x')
xlim([0.5 4])
xlabel('Day Number')
ylabel('Natural Frequency (in rad/s) of Floor 2')
title('Natural Frequency of Floor 2 v/s Day Number')

% Add text annotations for each point
for i = 1:3
    text(i, w(i, 2), ['(', num2str(i), ',', num2str(w(i, 2)), ')'], 'VerticalAlignment', 'bottom', 'HorizontalAlignment', 'left');
end

% Plot damping for Floor 1 and Floor 2 over days
figure;
plot([1 2 3], zita(:, 1)', '-.x')
hold on;
plot([1 2 3], zita(:, 2)', '--d')
xlim([0 4]);
legend('Floor 1','Floor 2','Location','best');
xlabel('Day Number')
ylabel('Damping')
title('Damping v/s Day Number')

% Add text annotations for each point
for i = 1:3
    if i == 3
        text(i, zita(i, 1), ['(', num2str(i), ',', num2str(zita(i, 1)), ')'], 'VerticalAlignment', 'bottom', 'HorizontalAlignment', 'right');
    else
        text(i, zita(i, 1), ['(', num2str(i), ',', num2str(zita(i, 1)), ')'], 'VerticalAlignment', 'top', 'HorizontalAlignment', 'right');
    end
end

% Add text annotation for a specific point
text(3, zita(3, 2), ['(', num2str(3), ',', num2str(zita(3, 2)), ')'], 'VerticalAlignment', 'top', 'HorizontalAlignment', 'left');
