clear;close all;
clearvars;
clc;
%% importing the data
sampling_rate = 200; dt = 1/sampling_rate;%in sec

f = readmatrix('HW2_measurements.txt'); %Measurements at sample frequency of 200Hz
t = f(:,1);
a1 = f(:,2);
a2 = f(:,3);

fg = readmatrix('HW1_Q2_El_Centro.txt'); %Ground Motion at sample frequency of 50Hz
t2 = fg(:,1);
ug = fg(:,2);

ug = interp1(t2,ug,t); %Ground Motion interpolated to 200Hz

%% setting the system properties

%% Defining System Properties

syms y1 y2 dy1 dy2 k1 k2 c1 c2 u du  % defining the system variables
%System Parameters
M = [10 0; 0 10]; %in kg      
K = [k1+k2 -k2; -k2 k2];%.*1000; %in N/m 
C = [c1+c2 -c2; -c2 c2]; %in N-s/m
Ig = [1; 1];

Y = [y1; y2];
dY = [dy1; dy2];

Z = [Y; dY; k1; k2; c1; c2];   % state vector
dZ = [dY;-(M\(K*Y))-(M\(C*dY))-Ig*u; 0; 0; 0; 0]; % derivative of state vector
H = -(M\(K*Y))-(M\(C*dY));  % y_k = H(z_k,u_k) non linear measurement function
g1 = dZ;  
g2 = subs(dZ,u,(u+(2/3*du))); % in dZ substitute u with u+2/3*du
g2 = subs(g2,Z,Z+(2/3*dt)*g1); 
F = Z + (g1 + (g2.*3)).*(dt/4); % z_(k+1) = F(z_k,u_k) state transitions non linear

%%
N = 8;
lambda = -7.97;
alpha = 0.1;
beta = 0;
Wom = (lambda/(N+lambda));%-265.67;
Woc = Wom + (1 - alpha^2 + beta);
Wim = (1/(2*(N+lambda)));
Wic = Wim;

%%
Nx = 8; % number of states
Ny = 2;% number of outputs

%Initialization
Xu = [0; 0; 0; 0; 5000; 5000; 50; 50]; % state vector initialisation
Pu = zeros(Nx); % covariance matrix initialisation

initial_var = 4; % According to Choice 1,2,3,4 as given in question
if initial_var == 1
    Pu(1,1) = 1e-2; Pu(2,2) = 1e-2; Pu(3,3) = 1e-2; Pu(4,4) = 1e-2;
    Pu(5,5) = 1e10; Pu(6,6) = 1e10; Pu(7,7) = 1e10; Pu(8,8) = 1e10;
elseif initial_var == 2
    Pu(1,1) = 1e-6; Pu(2,2) = 1e-6; Pu(3,3) = 1e-6; Pu(4,4) = 1e-6;
    Pu(5,5) = 1e6; Pu(6,6) = 1e6; Pu(7,7) = 1e6; Pu(8,8) = 1e6;
elseif initial_var == 3
    Pu(1,1) = 1e-6; Pu(2,2) = 1e-6; Pu(3,3) = 1e-6; Pu(4,4) = 1e-6;
    Pu(5,5) = 1e4; Pu(6,6) = 1e4; Pu(7,7) = 1e4; Pu(8,8) = 1e4;
else
    Pu(1,1) = 1e-10; Pu(2,2) = 1e-10; Pu(3,3) = 1e-8; Pu(4,4) = 1e-8;
    Pu(5,5) = 1e8; Pu(6,6) = 1e8; Pu(7,7) = 1e4; Pu(8,8) = 1e4;
end

process_noise = 1; %Enter 1,2,3 according to Choice 1,2,3 for Q
if process_noise == 1
    Q = zeros(Nx); %Nx x Nx
elseif process_noise == 2
    Q = zeros(Nx); %Nx x Nx
    Q(5,5) = 50; Q(6,6) = 50; Q(7,7) = 5e-6; Q(8,8) = 5e-6;
else
    Q = zeros(Nx); %Nx x Nx
    Q(5,5) = 5e3; Q(6,6) = 5e3; Q(7,7) = 5e-4; Q(8,8) = 5e-4;
end

R = [0.0438 0; 0 0.0967]; %Ny x Ny % Measurement noise

UKF_store = zeros(length(t),Nx);
UKF_store(1,:) = Xu'; %initialization

%% UKF loop
sigma_pts = zeros(Nx,2*N+1);
Xi = zeros(Nx,2*N+1);
Yi = zeros(Ny,2*N+1);

for i = 1:length(t)-1
    %Calculation of Sigma Points
    epsilon = 1e-6;
    L = chol((N+lambda)*Pu)';
    % generating the sigma points
    sigma_pts(:,1) = Xu;
    for j = 1:N
        sigma_pts(:,j+1) = Xu + L(:,j);
        sigma_pts(:,N+j+1) = Xu - L(:,j);
    end
        
    %State Prediction
    
    Xi(:,1) = nonlinearF(sigma_pts(1,1),sigma_pts(2,1),sigma_pts(3,1),sigma_pts(4,1),sigma_pts(5,1),sigma_pts(6,1),sigma_pts(7,1),sigma_pts(8,1),ug(i),(ug(i+1)-ug(i)));
    Xp = Wom*Xi(:,1);
    for j = 2:2*N+1
        Xi(:,j) = nonlinearF(sigma_pts(1,j),sigma_pts(2,j),sigma_pts(3,j),sigma_pts(4,j),sigma_pts(5,j),sigma_pts(6,j),sigma_pts(7,j),sigma_pts(8,j),ug(i),(ug(i+1)-ug(i)));
        Xp = Xp + Wim*Xi(:,j);        
    end
    
    Yi(:,1) = nonlinearH(Xi(1,1),Xi(2,1),Xi(3,1),Xi(4,1),Xi(5,1),Xi(6,1),Xi(7,1),Xi(8,1));
    Yp = Wom*Yi(:,1);
    for j = 2:2*N+1
        Yi(:,j) = nonlinearH(Xi(1,j),Xi(2,j),Xi(3,j),Xi(4,j),Xi(5,j),Xi(6,j),Xi(7,j),Xi(8,j));     
        Yp = Yp + Wim*Yi(:,j);
    end
    
    Pp = Woc*(Xi(:,1) - Xp)*((Xi(:,1) - Xp)');
    for j = 2:2*N+1
        Pp = Pp + Wic*(Xi(:,j) - Xp)*((Xi(:,j) - Xp)');
    end
    Pp = Pp + Q;
    
    %Kalman Gain Calculation
    Pxy = Woc*(Xi(:,1) - Xp)*((Yi(:,1) - Yp)');
    for j = 2:2*N+1
        Pxy = Pxy + Wic*(Xi(:,j) - Xp)*((Yi(:,j) - Yp)');
    end
        
    Pyy = Woc*(Yi(:,1) - Yp)*((Yi(:,1) - Yp)');
    for j = 2:2*N+1
        Pyy = Pyy + Wic*(Yi(:,j) - Yp)*((Yi(:,j) - Yp)');
    end
    Pyy = Pyy + R;
    
    Kg = Pxy/Pyy;
    
    %State Update
    Yk = [a1(i+1); a2(i+1)];
    Xu = Xp + Kg*(Yk - Yp);
    Pu = Pp - Kg*Pyy*(Kg');
    
    %Storage of State Vector
    UKF_store(i+1,:) = Xu';
end
%% Plotting of Graphs
figure;
plot(t,UKF_store(:,1));
ylabel('Displacement')
xlabel('Time')
saveas(gcf,'disp1.png')

figure;
plot(t,UKF_store(:,2));
ylabel('Displacement')
xlabel('Time')
saveas(gcf,'disp2.png')

figure;
plot(t,UKF_store(:,3));
ylabel('Velocity')
xlabel('Time')
saveas(gcf,'vel1.png')

figure;
plot(t,UKF_store(:,4));
ylabel('Velocity')
xlabel('Time')
saveas(gcf,'vel2.png')


figure;
plot(t,UKF_store(:,5));
ylabel('Stiffness')
xlabel('Time')
saveas(gcf,'k1.png')


figure;
plot(t,UKF_store(:,6));
ylabel('Stiffness')
xlabel('Time')
saveas(gcf,'k2.png')

figure;
plot(t,UKF_store(:,7));
ylabel('Damping')
xlabel('Time')
saveas(gcf,'c1.png')

figure;
plot(t,UKF_store(:,8));
ylabel('Damping')
xlabel('Time')
saveas(gcf,'c2.png')

