clear;close all;
clearvars;
clc;
%% importing the data
sampling_rate = 200; dt = 1/sampling_rate; %in sec

f = readmatrix('HW2_measurements.txt'); %Measurements at sample frequency of 50Hz
t = f(:,1);   % time steps
meas1 = f(:,2);   % meas1
meas2 = f(:,3);   % meas2

fg = readmatrix('HW1_Q2_El_Centro.txt'); %Ground Motion at sample frequency of 50Hz  
t2 = fg(:,1);
ug = fg(:,2);  % input u

ug = interp1(t2,ug,t); %Ground Motion interpolated to 200Hz 

%% Defining System Properties

syms y1 y2 dy1 dy2 k1 k2 c1 c2 u du  % defining the system variables using systematic math toolbox
%System Parameters
M = [10 0; 0 10]; %in kg      
K = [k1+k2 -k2; -k2 k2];%.*1000 for converting in N/m 
C = [c1+c2 -c2; -c2 c2]; %in N-s/m
Ig = [1; 1];

Y = [y1; y2];
dY = [dy1; dy2];

Z = [Y; dY; k1; k2; c1; c2];   % state vector
dZ = [dY;-(M\(K*Y))-(M\(C*dY))-Ig*u; 0; 0; 0; 0]; % derivative of state vector
H = -(M\(K*Y))-(M\(C*dY));  % y_k = H(z_k,u_k) non linear measurement function

% Ralston's approximation
g1 = dZ;  
g2 = subs(dZ,u,(u+(2/3*du))); % in dZ substitute u with u+2/3*du
A = (2/3*dt)*g1;
% p2 = subs(p3,[y1 y2 dy1 dy2 k1 k2 l1 l2],([(y1+A(1)) (y2+A(2)) (dy1+A(3)) (dy2+A(4)) (k1+A(5)) (k2+A(6)) (l1+A(7)) (l2+A(8))]));
g2 = subs(g2,Z,Z+A);

F = Z + (g1 + (g2.*3)).*(dt/4); % z_(k+1) = F(z_k,u_k) state transitions non linear
%% Calculation of Jacobians

J = jacobian(F,[y1 y2 dy1 dy2 k1 k2 c1 c2]);
G = jacobian(H,[y1 y2 dy1 dy2 k1 k2 c1 c2]);

%% Initialization of States

Nx = 8; %Nx is the number of state
Ny = 2; %Ny is the number of measurements

Zu = [0; 0; 0; 0; 5000; 5000; 50; 50];
Pu = zeros(Nx);
choice_init_cov = 4; % according to Choice 1,2,3,4 given in question
if choice_init_cov == 1
    Pu(1,1) = 1e-2; Pu(2,2) = 1e-2; Pu(3,3) = 1e-2; Pu(4,4) = 1e-2;
    Pu(5,5) = 1e10; Pu(6,6) = 1e10; Pu(7,7) = 1e10; Pu(8,8) = 1e10;  % assigning initial covariance matrices
elseif choice_init_cov == 2
    Pu(1,1) = 1e-6; Pu(2,2) = 1e-6; Pu(3,3) = 1e-6; Pu(4,4) = 1e-6;
    Pu(5,5) = 1e6; Pu(6,6) = 1e6; Pu(7,7) = 1e6; Pu(8,8) = 1e6;
elseif choice_init_cov == 3
    Pu(1,1) = 1e-6; Pu(2,2) = 1e-6; Pu(3,3) = 1e-6; Pu(4,4) = 1e-6;
    Pu(5,5) = 1e4; Pu(6,6) = 1e4; Pu(7,7) = 1e4; Pu(8,8) = 1e4;
else
    Pu(1,1) = 1e-10; Pu(2,2) = 1e-10; Pu(3,3) = 1e-8; Pu(4,4) = 1e-8;
    Pu(5,5) = 1e8; Pu(6,6) = 1e8; Pu(7,7) = 1e4; Pu(8,8) = 1e4;
end

 % corresponding to choice 1,2,3 for Q process noise
process_noise = 3;
if process_noise == 1
    Q = zeros(Nx); %Nx x Nx
elseif process_noise == 2
    Q = zeros(Nx); %Nx x Nx
    Q(5,5) = 50; Q(6,6) = 50; Q(7,7) = 5e-4; Q(8,8) = 5e-4;
else
    Q = zeros(Nx); %Nx x Nx
    Q(5,5) = 5e3; Q(6,6) = 5e3; Q(7,7) = 5e-2; Q(8,8) = 5e-2; % assigning process noises as given in question
end

R = [0.0438 0; 0 0.0967]; 

EKF_store = zeros(length(t),Nx);
EKF_store(1,:) = Zu'; %initialization

%% Main Loop Calculations


for i = 1:length(t)-1
    %State Prediction    

    Zp = nonlinearF(Zu(1),Zu(2),Zu(3),Zu(4),Zu(5),Zu(6),Zu(7),Zu(8),ug(i),(ug(i+1)-ug(i)));
    
    [Jk,Gk]=Jacobian_fn(Zu(1),Zu(2),Zu(3),Zu(4),Zu(5),Zu(6),Zu(7),Zu(8),ug(i));

    Pp = Jk*Pu*(Jk') + Q;
    
    %Kalman Gain Calculation
    Kg = Pp*(Gk')/(Gk*Pp*(Gk') + R);
    
    %State Update
    Yk = [meas1(i+1); meas2(i+1)];

    Zu = Zp + Kg*(Yk - nonlinearH(Zp(1),Zp(2),Zp(3),Zp(4),Zp(5),Zp(6),Zp(7),Zp(8)));

    Pu = (eye(Nx) - Kg*Gk)*Pp;
    
    %Storage of State Vector
    EKF_store(i+1,:) = Zu';
end

%% Plotting of Graphs
figure;
plot(t,EKF_store(:,1));
ylabel('Displacement')
xlabel('Time')
saveas(gcf,'y1.png')

figure;
plot(t,EKF_store(:,2));
ylabel('Displacement')
xlabel('Time')
saveas(gcf,'y2.png')

figure;
plot(t,EKF_store(:,3));
ylabel('Velocity')
xlabel('Time')
saveas(gcf,'y1_dot.png')

figure;
plot(t,EKF_store(:,4));
ylabel('Velocity')
xlabel('Time')
saveas(gcf,'y2_dot.png')

figure;
plot(t,EKF_store(:,5));
ylabel('Stiffness')
xlabel('Time')
saveas(gcf,'k1.png')


figure;
plot(t,EKF_store(:,6));
ylabel('Stiffness')
xlabel('Time')
saveas(gcf,'k2.png')

figure;
plot(t,EKF_store(:,7));
ylabel('Damping')
xlabel('Time')
saveas(gcf,'c1.png')

figure;
plot(t,EKF_store(:,8));
ylabel('Damping')
xlabel('Time')
saveas(gcf,'c2.png')
