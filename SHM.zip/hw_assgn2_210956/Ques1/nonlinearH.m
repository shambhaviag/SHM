function H = nonlinearH(y1,y2,y1_dot,y2_dot,k1,k2,c1,c2)
H(1,1) = (y2_dot*c2)/10 - (y1_dot*c2)/10 - (y1_dot*c1)/10 - (k1*y1)/10 - (k2*y1)/10 + (k2*y2)/10;
H(2,1) = (y1_dot*c2)/10 - (y2_dot*c2)/10 + (k2*y1)/10 - (k2*y2)/10;
end